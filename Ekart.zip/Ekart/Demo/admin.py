from django.contrib import admin

from Demo.models import Student,Employe

# Register your models here.
# class student(admin.ModelAdmin):
#     list_display =["Name","Branch"]
class employe(admin.ModelAdmin):
    list_display= ["Name","Branch"]    
admin.site.register(Student)
admin.site.register(Employe,employe)
